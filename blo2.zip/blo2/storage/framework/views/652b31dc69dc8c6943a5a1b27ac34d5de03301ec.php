
 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h3>School Management System</h3>
            </div>
            <div class="pull-right">
                <a class="btn btn-danger" href="<?php echo e(route('marks.create')); ?>"> Create Marks</a>
            </div>
            
            <div class="pull-right" style="padding-right:20px;">
                <a class="btn btn-success" href="<?php echo e(route('students.index')); ?>"> Student List</a>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>History</th>
            <th>Science</th>
            <th>Maths</th>
            <th>Total Marks</th>
            <th>Term</th>
            <th>Created on</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
       $marksTotal = 0;
       $marksTotal = $mark->history + $mark->maths + $mark->science;  ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($mark->student->name); ?></td>
            <td><?php echo e($mark->history); ?></td>
            <td><?php echo e($mark->science); ?></td>
            <td><?php echo e($mark->maths); ?></td>
            <td><?php echo e($marksTotal); ?></td>
            <td><?php echo e($mark->term); ?></td>
            <td><?php echo e($mark->created_at); ?></td>
            <td>
                <form action="<?php echo e(route('marks.destroy',$mark->id)); ?>" method="POST">
   
    
                    <a class="btn btn-primary" href="<?php echo e(route('marks.edit',$mark->id)); ?>">Edit</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
    <?php echo $marks->links(); ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('marks.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\diz\blo2\resources\views/marks/index.blade.php ENDPATH**/ ?>