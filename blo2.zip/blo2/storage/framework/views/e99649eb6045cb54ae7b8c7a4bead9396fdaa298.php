
   
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Marks</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('marks.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
   
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
  
    <form action="<?php echo e(route('marks.update',$mark->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
   
        <div class="form-group">
            <label for="exampleFormControlSelect1">Name</label>
                <select class="form-control" name ="name" disabled="true" id="exampleFormControlSelect1">
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($student->id); ?>"  <?php echo e($student->id == $mark->name ? 'selected' : ''); ?>><?php echo e($student->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>MAths:</strong>
                <input type="number" value="<?php echo e($mark->maths); ?>"  name="maths" class="form-control" placeholder="Maths">
            </div>
        </div> <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Science:</strong>
                <input type="number"  value="<?php echo e($mark->science); ?>"  name="science" class="form-control" placeholder="Science">
            </div>
        </div> <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>History:</strong>
                <input type="number" value="<?php echo e($mark->history); ?>"  name="history" class="form-control" placeholder="History">
            </div>
        </div>
    
        <div class="col-xs-12 col-sm-12 col-md-12">
  
        <div class="form-group">
            <label for="exampleFormControlSelect1">Term</label>
                <select class="form-control" name ="term" id="exampleFormControlSelect1">
                    <option value="One" <?php echo e($mark->term == 'One' ? 'selected' : ''); ?>>One</option>
                    <option value="Two" <?php echo e($mark->term == 'Two' ? 'selected' : ''); ?>>Two</option>
                    <option value="Three" <?php echo e($mark->term == 'Three' ? 'selected' : ''); ?>>Three</option>
                </select>
        </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
   
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('marks.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\diz\blo2\resources\views/marks/edit.blade.php ENDPATH**/ ?>